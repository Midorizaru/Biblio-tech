export default function Home() {
  return (
    <div>
      <h1>Welcome to the Library</h1>
      <p>Use the search bar to find books.</p>
    </div>
  );
}